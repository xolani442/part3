import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;
import java.util.*;

@Test
public void testSentMessagesArray(){
    
    assertEquals(
    "did you go to school",
            sentMessages.get(0).getMessage()
    );
    assertEquals(
    "i thought you were going there",
            sentMessages.get(1).getMessage()
    );
    
}

@Test
public void testSearchRecipient(){
    
    String expected =
            "i am not there yet";
    assertEquals(expected,storedMessages.get(0).getMessage());
    
}



