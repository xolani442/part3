import java.util.ArrayList;
import java.util.UUID;

public class message {
    private String messageID;
    private String recipient;
    private String message;
    private static ArrayList<Message>sentMessages = new ArrayList<>();
    private static ArrayList<message>storedMessage = new ArrayList<>();
    private static ArrayList<message>disregardedMessages = new ArrayList<>();
    private static ArrayList<String>messageHashes = new ArrayList<>();
    private static ArrayList<String>messageIDs = new ArrayList<>();
    public message(String recipient,String message){
        this.messageID = UUID.randomUUID().toString().substring(0,10);
        this.recipient = recipient;
        this.message = message;
               
    }
    public String getMessageID(){
        return messageID;
    }
    public String getRecipient(){
        return recipient;
    }
    public String getmessage(){
        return message;
    }
    public String createMessageHash(){
        String[] words = message.split(message);
        string hash = 
                messageID.substring(0,2)+":"+
                messageID.substring(messageID.length()-2)+':'+
                words[0].toUpperCase()+
                words[words.length-1].toUpperCase();
        return hash;
    }
    public static void addSentMessage(message msg){
        sentMessages.add(msg);
        messageHashes.add(msg.createMessageHash());
        messageIDs.add(msg.getMessageID());
    }
    public ststic void addStoredMessage(message msg){
        storedMessage.add(msg);
        messageHashes.add(msg.createMessageHash());
        messageIDs.add(msg.getMessageID());
    }
    public static void addDisregardedMessage(message msg){
        disregardedMessages.add(msg);
    }
    public static void displayStoredMessages(){
        for(message msg:storedMessages){
            System.out.println("Sender :Developer ");
            System.out.println("Recipient:"+msg.getRecipient());
                    
        }
    }
    public static void displayLongestStoredMessage(){
        Message longest = storedMessages.get(0);
        for(message msg : storedMessage){
            if(msg.getmessage().length()>
                    longest.getMessage().lenght()){
                longest = msg;
            }
        }
        system.out.println(longest.getMessage());
    }
    public static void searchRecipient(String recipient){
        system.out.println(longest.getMessage());
    }
    public static void searchRecipient(String recipient){
        for(message msg : storedMessages){
            if(msg.getRecipient().equals(recipient)){
                system.out.println(msg.getmessage());
            }
        }
    }
    public static void displayReport(){
        for(Message msg : sentMessages){
            system.out.println("messageID:"
            + msg.getMessageID());
            system.out.println("message Hash:"
            + msg.createMessageHash());
            system.out.println("Recipient:"
            + msg.getRecipient());
            system.out.println("message:"
            + msg.getMessage());
        }
    }
    
}

Test Data;

message 1

recipient: +27765776387

message: Did you go to school?

flag: sent

message2

recipient: +27769962279

message: i thought you were going there

flag: stored

message3

recipient: +27769962279

message: iam not there yet

flag: Desregard

message4

recipient: +27769962279

message: lets make money

flag: sent

message5

recipient: +27769962279

message: i dont know if you get it or not

flag: Stored

